
<script src="<?=base_url()?>template/devoops/plugins/dialog/messi.min.js"></script>
<link rel="stylesheet" href="<?=base_url()?>template/devoops/plugins/dialog/messi.min.css" />
<div Class="head-page-title">
</div>
 <div class="register-form">
					 <div class="white-back page-content">
                                             <div class="daviplata">
                                                 <h4>La forma más <b>facíl y gratis</b> con tu celular sin una cuenta en la entidad, sin tarjetas de débito/crédito.</h4>
                                                
                                                 <img style="margin-left: 10px;" src="<?=base_url()?>template/devoops/img/daviplata.jpg" title="Daviplata"/>
                                                  <p>
                                                      Davivienda hace esto simple con tan solo <a href="https://daviplata.com/wps/portal/daviplata/Home/ComoActivarse/!ut/p/b1/04_SjzQysDA1NDQ3M7fQj9CPykssy0xPLMnMz0vMAfGjzOKNLQJN_LycjHydQ11cDRwDvQ1MXUMNvdydjIEKIoEKDHAARwNC-sP1o8BKTNw9fQxdzQIczQJC3AwczdxcPY18jY3cHY2hCvBY4eeRn5uqnxuVY-mp66gIAOt25xc!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">activar Daviplata</a> en tu celular y <a href="https://daviplata.com/wps/portal/daviplata/Home/ComoMeterlePlata/OficinasDavivienda/!ut/p/b1/jc7LDoIwEIXhZ-EJZmihlOWIgFRB8BKlG4OJIY1cNsbntxpXJqKzm-Q7yQ8aaobSd91ABBKOoIfmbtrmZsah6Z6_FicuK69QM5ZHxZyQqu2e1kJxVGhBbYGXZis3FiWJcpcgiSTOWM5ZSvy_PX45wl97BbrtxrNNPYD-wESRxcswpI2PmHlvMBX7AhM1xWLsL9DrLpFXU7bkOA8vyVeM/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">recargar saldo</a> en cualquier oficina de Davivienda.
                                                      <br>
                                                      <br>
                                                      <a href="https://daviplata.com/Documents/wcm?biblio=DaviPlata&nombre=InfoGeneralTablaTarifasYLimites" target="_blank"><img style="" src="<?=base_url()?>template/devoops/img/info-icon.png" title="Información"/>&nbsp;Tarifas y limites</a>
                                                      <br>
                                                      <div class="boxing1 depositar" style="max-width: 133px;">
                                                        <div class="box-heading">
                                                       <img src="<?=base_url()?>template/devoops/img/money-cion.png">&nbsp;Depositar
                                                        </div>
                                                      </div>
                                                 </p>
                                                 <div class="deposito-daviplata" style="display:none">
                                                     <div style="max-width: 250px;">
                                                     <p>Una vez tenga activado y recargado Daviplata en tu celular. Por favor usar el número de celular <b>3177246661</b> para pasar plata a LatinGana.</p>
                                                     <ul class="ul-steps-daviplata">
                                                         <li><a href="https://daviplata.com/wps/portal/daviplata/Home/ComoActivarse/!ut/p/b1/04_SjzQysDA1NDQ3M7fQj9CPykssy0xPLMnMz0vMAfGjzOKNLQJN_LycjHydQ11cDRwDvQ1MXUMNvdydjIEKIoEKDHAARwNC-sP1o8BKTNw9fQxdzQIczQJC3AwczdxcPY18jY3cHY2hCvBY4eeRn5uqnxuVY-mp66gIAOt25xc!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">Activar Daviplata.</a></li>
                                                         <li><a href="https://daviplata.com/wps/portal/daviplata/Home/ComoMeterlePlata/OficinasDavivienda/!ut/p/b1/jc7LDoIwEIXhZ-EJZmihlOWIgFRB8BKlG4OJIY1cNsbntxpXJqKzm-Q7yQ8aaobSd91ABBKOoIfmbtrmZsah6Z6_FicuK69QM5ZHxZyQqu2e1kJxVGhBbYGXZis3FiWJcpcgiSTOWM5ZSvy_PX45wl97BbrtxrNNPYD-wESRxcswpI2PmHlvMBX7AhM1xWLsL9DrLpFXU7bkOA8vyVeM/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">Recargar.</a></li>
                                                         <li><a href="https://daviplata.com/wps/portal/daviplata/Home/TodoLoQuePuedoHacer/PasarPlata/!ut/p/b1/04_SjzQ0NbAwMbUwtzTUj9CPykssy0xPLMnMz0vMAfGjzOKNLQJN_LycjHy93YIsDRwDPX1DjB1DjQ0czYAKIoEKDHAARwNC-sP1o8BKTNw9fQxdzQIczQJC3IASbq6eRr7GRu6OxlAFeKzw88jPTdXPjcqx9NR1VAQAgU2NAw!!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">Pasar plata</a>.</li>
                                                     </ul>
                                                     <small>
                                                         Cuando recibamos la notificación de tu pago a través de nuestro celular, te recargaremos tu cuenta LatinGana en un plazo de 12 horas. Por eso debes pasar plata desde tu número celular registrado en LatinGana. 
                                                     </small>
                                                     </div>
                                                 </div>
                                             </div>
                                             <div class="daviplata" style="margin-top: 10px">
                                                 <h4>Depositos rápidos e instantáneos pero no gratis.</h4>
                                                 <img style="margin-left: 10px;" src="<?=base_url()?>template/devoops/img/paygol.png" title="Daviplata"/><br>
                                                 <img style="margin-left: 10px;max-width: 100%;" src="<?=base_url()?>template/devoops/img/paygol-cobertura.jpg" title="Daviplata"/>
                                                <form name="pg_frm" method="post" action="https://www.paygol.com/pay" >
                                                <input type="hidden" name="pg_serviceid" value="344021">
                                                <input type="hidden" name="pg_currency" value="COP">
                                                <input type="hidden" name="pg_name" value="Deposito">
                                                <input type="hidden" name="pg_custom" value="">


                                                <div>Deposito de:</div>
                                              <!-- With Option buttons -->
                                              <p><input type="radio" name="pg_price" value="1"checked>&nbsp;$5000</p>
                                                 <p><input type="radio" name="pg_price" value="2">&nbsp;$10.000</p>
                                                 <p><input type="radio" name="pg_price" value="3">&nbsp;$20.000</p>
                                                 <p><input type="radio" name="pg_price" value="4">&nbsp;$30.000</p>
                                                 <p><input type="radio" name="pg_price" value="5">&nbsp;$40.000</p>
                                                 <p><input type="radio" name="pg_price" value="6">&nbsp;$50.000</p>
                                                <p> <input type="radio" name="pg_price" value="7">&nbsp;$60.000</p>
                                                <p><input type="radio" name="pg_price" value="8">&nbsp;$70.000</p>
                                                <p> <input type="radio" name="pg_price" value="9">&nbsp;$80.000</p>
                                                 <p><input type="radio" name="pg_price" value="10">&nbsp;$90.000<p>
                                                     
                                                <input type="hidden" name="pg_return_url" value="http://latingana.com/account">
                                                <input type="hidden" name="pg_cancel_url" value="http://latingana.com/account/deposit_failed">
                                                 <div style="clear: both; padding-bottom: 10px;   padding-top: 17px;"> <a href="https://www.paygol.com/country/co" target="_blank"><img src="<?=base_url()?>template/devoops/img/info-icon.png" title="Información"/>&nbsp;Calcular tarifas</a></div>
                                                 <div style="clear: both;"> <input style="max-width:200px;" type="image" name="pg_button" src="https://www.paygol.com/webapps/buttons/es/white.png" border="0" alt="Realiza pagos con PayGol: la forma mas facil!" title="Realiza pagos con PayGol: la forma mas facil!" >     </div>
                                             </form> 
                                             </div>

	   </div>
       </div>
<script>
   $(document).on("click",".depositar",function()
	{	
	  var content = $(".deposito-daviplata").html();
	  new Messi(content, {title:"Daviplata - Depositar" , modal: true});
	});
</script>