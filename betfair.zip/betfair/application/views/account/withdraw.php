
<script src="<?=base_url()?>template/devoops/plugins/dialog/messi.min.js"></script>
<link rel="stylesheet" href="<?=base_url()?>template/devoops/plugins/dialog/messi.min.css" />
<div Class="head-page-title">
</div>
 <div class="register-form">
					 <div class="white-back page-content">
                                             <div class="daviplata">
                                                 <h4>La forma más <b>facíl y gratis</b> para recibir plata en tu celular y cobrar en cualquier oficina de Davivienda sin una cuenta en la entidad, sin tarjetas de débito/crédito.</h4>
                                                
                                                 <img style="margin-left: 10px;" src="<?=base_url()?>template/devoops/img/daviplata.jpg" title="Daviplata"/>
                                                  <p>
                                                      Davivienda hace esto simple con tan solo <a href="https://daviplata.com/wps/portal/daviplata/Home/ComoActivarse/!ut/p/b1/04_SjzQysDA1NDQ3M7fQj9CPykssy0xPLMnMz0vMAfGjzOKNLQJN_LycjHydQ11cDRwDvQ1MXUMNvdydjIEKIoEKDHAARwNC-sP1o8BKTNw9fQxdzQIczQJC3AwczdxcPY18jY3cHY2hCvBY4eeRn5uqnxuVY-mp66gIAOt25xc!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">activar Daviplata</a> en tu celular y <a href="https://daviplata.com/wps/portal/daviplata/Home/TodoLoQuePuedoHacer/SacarPlata/!ut/p/b1/04_SjzS0MDIztjS1MLXQj9CPykssy0xPLMnMz0vMAfGjzOKNLQJN_LycjHy93YIsDRwDPX1DjB1DjQ08TYEKIoEKDHAARwNC-sP1o8BKTNw9fQxdzQIczQJC3AwczdxcPY18jY3cHY2hCvBY4eeRn5uqnxuVY-mp66gIABpzbj0!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">sacar la plata</a> de tus ganancias en cualquier oficina de Davivienda.
                                                      <br>
                                                      <br>
                                                      <a href="https://daviplata.com/Documents/wcm?biblio=DaviPlata&nombre=InfoGeneralTablaTarifasYLimites" target="_blank"><img style="" src="<?=base_url()?>template/devoops/img/info-icon.png" title="Información"/>&nbsp;Tarifas y limites</a>
                                                      <br>
													  <label>Valor a retirar:</label>&nbsp; &nbsp;$<input type="text" style="    max-width: 111px;"/>
                                                      <div class="boxing1 depositar" style="max-width: 109px;">
                                                        <div class="box-heading">
                                                       <img src="<?=base_url()?>template/devoops/img/withdraw-icon.png">&nbsp;Retirar
                                                        </div>
                                                      </div>
                                                 </p>
                                                 <div class="deposito-daviplata" style="display:none">
                                                     <div style="max-width: 250px;">
                                                     <p>Una vez tenga activado y recargado Daviplata en tu celular. Por favor usar el número de celular <b>3177246661</b> para pasar plata a LatinGana.</p>
                                                     <ul class="ul-steps-daviplata">
                                                         <li><a href="https://daviplata.com/wps/portal/daviplata/Home/ComoActivarse/!ut/p/b1/04_SjzQysDA1NDQ3M7fQj9CPykssy0xPLMnMz0vMAfGjzOKNLQJN_LycjHydQ11cDRwDvQ1MXUMNvdydjIEKIoEKDHAARwNC-sP1o8BKTNw9fQxdzQIczQJC3AwczdxcPY18jY3cHY2hCvBY4eeRn5uqnxuVY-mp66gIAOt25xc!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">Activar Daviplata.</a></li>
                                                         <li><a href="https://daviplata.com/wps/portal/daviplata/Home/ComoMeterlePlata/OficinasDavivienda/!ut/p/b1/jc7LDoIwEIXhZ-EJZmihlOWIgFRB8BKlG4OJIY1cNsbntxpXJqKzm-Q7yQ8aaobSd91ABBKOoIfmbtrmZsah6Z6_FicuK69QM5ZHxZyQqu2e1kJxVGhBbYGXZis3FiWJcpcgiSTOWM5ZSvy_PX45wl97BbrtxrNNPYD-wESRxcswpI2PmHlvMBX7AhM1xWLsL9DrLpFXU7bkOA8vyVeM/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">Recargar.</a></li>
                                                         <li><a href="https://daviplata.com/wps/portal/daviplata/Home/TodoLoQuePuedoHacer/PasarPlata/!ut/p/b1/04_SjzQ0NbAwMbUwtzTUj9CPykssy0xPLMnMz0vMAfGjzOKNLQJN_LycjHy93YIsDRwDPX1DjB1DjQ0czYAKIoEKDHAARwNC-sP1o8BKTNw9fQxdzQIczQJC3IASbq6eRr7GRu6OxlAFeKzw88jPTdXPjcqx9NR1VAQAgU2NAw!!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/" target="_blank">Pasar plata</a>.</li>
                                                     </ul>
                                                     <small>
                                                         Cuando recibamos la notificación de tu pago a través de nuestro celular, te recargaremos tu cuenta LatinGana en un plazo de 12 horas. Por eso debes pasar plata desde tu número celular registrado en LatinGana. 
                                                     </small>
                                                     </div>
                                                 </div>
                                             </div>
                                             <div class="daviplata" style="margin-top: 10px">
                                                 <h4>pagos rápidos pero no es gratis.</h4>
                                                 <img style="margin-left: 10px;" src="<?=base_url()?>template/devoops/img/logoefecty.png" title="Daviplata"/><br>
												 <a href=" https://www.efecty.com.co/webefecty/calculadora-giros-lightbox.html" target="_blank"><img style="" src="<?=base_url()?>template/devoops/img/info-icon.png" title="Información"/>&nbsp;Tarifas</a>
												 <br>
												  <label>Valor a retirar:</label>&nbsp; &nbsp;$<input type="text" style="    max-width: 111px;"/>
												  <div><label>Tarifa:</label>&nbsp; &nbsp;$4700</div>
												  <div><label>Total:</label>&nbsp; &nbsp;$14700</div>
												<div class="boxing1 depositar" style="max-width: 109px;">
                                                        <div class="box-heading">
                                                       <img src="<?=base_url()?>template/devoops/img/withdraw-icon.png">&nbsp;Retirar
                                                        </div>
                                                      </div>
                                             </div>

	   </div>
       </div>
<script>
   $(document).on("click",".depositar",function()
	{	
	  var content = $(".deposito-daviplata").html();
	  new Messi(content, {title:"Daviplata - Depositar" , modal: true});
	});
</script>