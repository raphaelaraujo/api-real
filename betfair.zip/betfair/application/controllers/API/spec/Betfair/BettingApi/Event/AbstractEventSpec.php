<?php

namespace spec\Betfair\BettingApi\Event;

use spec\Betfair\AbstractBetfairObjectSpec;

abstract class AbstractEventSpec  extends AbstractBetfairObjectSpec
{
}
