<?php

namespace Betfair\Model;

abstract class OrderProjection
{
    const EXECUTION_COMPLETE    = "EXECUTION_COMPLETE";
    const EXECUTABLE            = "EXECUTABLE";
    const ALL                   = "ALL";
}
