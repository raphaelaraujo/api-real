<?php

namespace Betfair\Model;

abstract class SortDir
{
    const EARLIEST_TO_LATEST = "EARLIEST_TO_LATEST";
    const LATEST_TO_EARLIEST = "LATEST_TO_EARLIEST";
}
