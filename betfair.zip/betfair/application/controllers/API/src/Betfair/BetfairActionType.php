<?php

namespace Betfair;

abstract class BetfairActionType
{
    const BETTING = "betting";
    const ACCOUNT = "account";
}
