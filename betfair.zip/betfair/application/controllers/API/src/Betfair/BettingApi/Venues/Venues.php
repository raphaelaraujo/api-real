<?php

namespace Betfair\BettingApi\Venues;

use Betfair\BettingApi\BetfairMarketFilterObject;

class Venues extends BetfairMarketFilterObject
{
    const API_METHOD_NAME = "listVenues";
}
